package com.wallpaper.debalekha.wallpaper;

/**
 * Created by Tushar on 9/10/2017.
 */

class Constant {
    public static int nav_clicked = 0;
    public static Boolean isNavClicked = false;

    public static Boolean isToggle = true;

    public static int color = 0xff3b5998;
    public static int theme = R.style.AppTheme;
}
